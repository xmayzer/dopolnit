package com.example.dopoln

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
